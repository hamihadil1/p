# 5_👨‍🏫_Professeurs.py - صفحة الأستاذ
import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import datetime, timedelta
from database import db

# إعداد الصفحة
st.set_page_config(
    page_title="Professeur - Examens Universitaires",
    page_icon="👨‍🏫",
    layout="wide"
)

# ============================================
# STYLES CSS
# ============================================
st.markdown("""
<style>
    .prof-header {
        font-size: 2.5rem;
        background: linear-gradient(90deg, #8B5CF6, #EC4899);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-align: center;
        margin-bottom: 1rem;
    }
    .surveillance-card {
        background: white;
        padding: 1.5rem;
        border-radius: 12px;
        box-shadow: 0 6px 20px rgba(0,0,0,0.1);
        margin-bottom: 1.5rem;
        border-left: 6px solid #8B5CF6;
    }
    .responsable-card {
        border-left: 6px solid #10B981;
        background: linear-gradient(135deg, #F0FDF4, #FFFFFF);
    }
    .stats-card {
        background: linear-gradient(135deg, #F5F3FF, #FFFFFF);
        padding: 1.5rem;
        border-radius: 12px;
        border: 2px solid #8B5CF6;
    }
</style>
""", unsafe_allow_html=True)

# ============================================
# PAGE TITLE
# ============================================
st.markdown('<h1 class="prof-header">👨‍🏫 Espace Professeur</h1>', unsafe_allow_html=True)

# ============================================
# SIMULATION DE CONNEXION PROFESSEUR
# ============================================
st.sidebar.header("👤 Connexion Professeur")

try:
    # Récupérer la liste des professeurs
    df_professeurs = db.execute_query("""
        SELECT id, matricule, nom, prenom, dept_id, specialite 
        FROM gestion_examens.professeurs 
        WHERE statut = 'actif'
        LIMIT 20
    """)
    
    if not df_professeurs.empty:
        prof_liste = [
            f"{row['matricule']} - {row['prenom']} {row['nom']}" 
            for _, row in df_professeurs.iterrows()
        ]
        prof_ids = [row['id'] for _, row in df_professeurs.iterrows()]
        prof_depts = [row['dept_id'] for _, row in df_professeurs.iterrows()]
    else:
        prof_liste = ["PROF-INF-011 - Jean-Paul Martin"]
        prof_ids = [1]
        prof_depts = [1]

except:
    prof_liste = ["PROF-INF-011 - Jean-Paul Martin"]
    prof_ids = [1]
    prof_depts = [1]

# Sélection du professeur
selected_prof = st.sidebar.selectbox(
    "Sélectionnez votre compte",
    options=prof_liste,
    index=0
)

# Récupérer l'ID du professeur
prof_idx = prof_liste.index(selected_prof)
prof_id = prof_ids[prof_idx]
prof_dept = prof_depts[prof_idx]

# ============================================
# ONGLETS PRINCIPAUX
# ============================================
tab1, tab2, tab3, tab4 = st.tabs([
    "📅 Mes Surveillances", 
    "📝 Mes Examens Responsable", 
    "📊 Mes Statistiques", 
    "📚 Mes Modules"
])

# ============================================
# TAB 1: SURVEILLANCES
# ============================================
with tab1:
    st.header("📅 Mes Surveillances d'Examens")
    
    try:
        # Récupérer les surveillances du professeur
        df_surveillances = db.execute_query("""
            SELECT 
                s.id,
                s.role,
                s.priorite,
                s.heures_creditees,
                m.nom as module,
                f.nom as formation,
                pr.prenom || ' ' || pr.nom as responsable,
                sa.nom as salle,
                sa.type as type_salle,
                TO_CHAR(e.date_heure, 'DD/MM/YYYY') as date_examen,
                TO_CHAR(e.date_heure, 'HH24:MI') as heure_examen,
                e.date_heure,
                e.duree_minutes,
                e.statut
            FROM gestion_examens.surveillances s
            JOIN gestion_examens.examens e ON s.examen_id = e.id
            JOIN gestion_examens.modules m ON e.module_id = m.id
            JOIN gestion_examens.formations f ON e.formation_id = f.id
            JOIN gestion_examens.professeurs pr ON e.professeur_responsable_id = pr.id
            JOIN gestion_examens.salles_examen sa ON e.salle_id = sa.id
            WHERE s.professeur_id = %s
            ORDER BY e.date_heure
        """, (prof_id,))
        
        if not df_surveillances.empty:
            # Statistiques des surveillances
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                total_surv = len(df_surveillances)
                st.metric("📊 Total surveillances", total_surv)
            
            with col2:
                heures_total = df_surveillances['heures_creditees'].sum()
                st.metric("⏱️ Heures créditées", f"{heures_total:.1f}h")
            
            with col3:
                surv_aujourdhui = df_surveillances[
                    df_surveillances['date_examen'] == datetime.now().strftime('%d/%m/%Y')
                ].shape[0]
                st.metric("📅 Aujourd'hui", surv_aujourdhui)
            
            with col4:
                surv_semaine = df_surveillances[
                    pd.to_datetime(df_surveillances['date_heure']) <= datetime.now() + timedelta(days=7)
                ].shape[0]
                st.metric("🗓️ Cette semaine", surv_semaine)
            
            st.markdown("---")
            
            # Filtres
            col1, col2 = st.columns(2)
            
            with col1:
                # Filtre par rôle
                roles = ["Tous rôles"] + df_surveillances['role'].unique().tolist()
                selected_role = st.selectbox("Filtrer par rôle", roles)
            
            with col2:
                # Filtre par statut
                status = ["Tous statuts"] + df_surveillances['statut'].unique().tolist()
                selected_status = st.selectbox("Filtrer par statut", status)
            
            # Appliquer les filtres
            filtered_surv = df_surveillances.copy()
            
            if selected_role != "Tous rôles":
                filtered_surv = filtered_surv[filtered_surv['role'] == selected_role]
            
            if selected_status != "Tous statuts":
                filtered_surv = filtered_surv[filtered_surv['statut'] == selected_status]
            
            # Afficher les surveillances
            if not filtered_surv.empty:
                st.subheader(f"👁️ {len(filtered_surv)} surveillances trouvées")
                
                for idx, surv in filtered_surv.iterrows():
                    # Déterminer la classe CSS
                    card_class = "surveillance-card"
                    if surv['role'] == 'responsable':
                        card_class = "responsable-card"
                    
                    # Calculer les jours restants
                    exam_date = pd.to_datetime(surv['date_heure'])
                    days_left = (exam_date - datetime.now()).days
                    
                    # Afficher la carte
                    with st.container():
                        role_icon = "👑" if surv['role'] == 'responsable' else "👁️"
                        priority_text = "Haute" if surv['priorite'] == 1 else "Normale"
                        priority_color = "#EF4444" if surv['priorite'] == 1 else "#3B82F6"
                        
                        st.markdown(f"""
                        <div class="{card_class}">
                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <div>
                                    <h3 style="margin: 0; color: #1F2937;">
                                        {role_icon} {surv['module']}
                                    </h3>
                                    <p style="margin: 0.5rem 0; color: #6B7280;">
                                        📚 {surv['formation']} | 👨‍🏫 Responsable: {surv['responsable']}
                                    </p>
                                </div>
                                <div style="text-align: right;">
                                    <h2 style="margin: 0; color: #8B5CF6;">{surv['heure_examen']}</h2>
                                    <p style="margin: 0; color: #6B7280;">{surv['date_examen']}</p>
                                </div>
                            </div>
                            
                            <div style="margin-top: 1rem; display: flex; justify-content: space-between; flex-wrap: wrap;">
                                <div>
                                    <span style="background: #F5F3FF; padding: 0.3rem 0.8rem; border-radius: 20px;">
                                        🏢 {surv['salle']} ({surv['type_salle']})
                                    </span>
                                    <span style="background: #F0F9FF; padding: 0.3rem 0.8rem; border-radius: 20px; margin-left: 0.5rem;">
                                        ⏱️ {surv['duree_minutes']} min
                                    </span>
                                    <span style="background: #FEF2F2; padding: 0.3rem 0.8rem; border-radius: 20px; margin-left: 0.5rem; color: {priority_color};">
                                        {priority_text} priorité
                                    </span>
                                </div>
                                
                                <div>
                                    <span style="background: {'#FEF2F2' if days_left <= 2 else '#F0FDF4'}; 
                                            padding: 0.3rem 0.8rem; border-radius: 20px; 
                                            color: {'#DC2626' if days_left <= 2 else '#059669'};">
                                        ⏳ {days_left} jours restants
                                    </span>
                                    <span style="background: #E0F2FE; padding: 0.3rem 0.8rem; border-radius: 20px; margin-left: 0.5rem;">
                                        💰 {surv['heures_creditees']}h créditées
                                    </span>
                                </div>
                            </div>
                            
                            <div style="margin-top: 1rem; padding: 0.8rem; background: #F9FAFB; border-radius: 8px;">
                                <strong>📋 Mes responsabilités:</strong>
                                <ul style="margin: 0.5rem 0; padding-left: 1.5rem;">
                                    <li>Vérification des identités des étudiants</li>
                                    <li>Distribution des sujets d'examen</li>
                                    <li>Surveillance pendant l'épreuve</li>
                                    <li>Collecte des copies</li>
                                </ul>
                            </div>
                        </div>
                        """, unsafe_allow_html=True)
                
                # Graphique des heures créditées
                st.markdown("---")
                st.subheader("📊 Analyse des heures créditées")
                
                # Préparer les données
                df_hours = filtered_surv.copy()
                df_hours['date'] = pd.to_datetime(df_hours['date_heure']).dt.date
                df_hours_by_date = df_hours.groupby('date')['heures_creditees'].sum().reset_index()
                
                col1, col2 = st.columns(2)
                
                with col1:
                    # Graphique en barres
                    fig = px.bar(
                        df_hours_by_date,
                        x='date',
                        y='heures_creditees',
                        title='Heures créditées par date',
                        color='heures_creditees',
                        color_continuous_scale='Viridis'
                    )
                    st.plotly_chart(fig, use_container_width=True)
                
                with col2:
                    # Graphique cumulatif
                    df_hours_by_date['cumul'] = df_hours_by_date['heures_creditees'].cumsum()
                    fig = px.line(
                        df_hours_by_date,
                        x='date',
                        y='cumul',
                        title='Heures créditées cumulées',
                        markers=True
                    )
                    st.plotly_chart(fig, use_container_width=True)
                
                # Téléchargement des données
                csv = filtered_surv.to_csv(index=False)
                st.download_button(
                    "📥 Télécharger mes surveillances (CSV)",
                    csv,
                    file_name=f"surveillances_prof_{prof_id}_{datetime.now().strftime('%Y%m%d')}.csv",
                    mime="text/csv"
                )
            
            else:
                st.info("🎉 Aucune surveillance trouvée avec les filtres sélectionnés")
        
        else:
            st.info("📭 Aucune surveillance programmée pour le moment")
            st.markdown("""
            <div class="stats-card">
                <h4 style="margin-top: 0;">ℹ️ Information</h4>
                <p>Vous n'avez actuellement aucune surveillance d'examen programmée.</p>
                <p>Les surveillances sont automatiquement attribuées par le système.</p>
                <p>Pour plus d'informations, contactez le service des examens.</p>
            </div>
            """, unsafe_allow_html=True)
    
    except Exception as e:
        st.error(f"Erreur lors du chargement des surveillances: {e}")

# ============================================
# TAB 2: EXAMENS RESPONSABLE
# ============================================
with tab2:
    st.header("📝 Mes Examens en tant que Responsable")
    
    try:
        # Récupérer les examens où le professeur est responsable
        df_examens_responsable = db.execute_query("""
            SELECT 
                e.id,
                m.nom as module,
                m.code as code_module,
                f.nom as formation,
                d.nom as departement,
                sa.nom as salle,
                sa.capacite,
                sa.type as type_salle,
                TO_CHAR(e.date_heure, 'DD/MM/YYYY') as date_examen,
                TO_CHAR(e.date_heure, 'HH24:MI') as heure_examen,
                e.date_heure,
                e.duree_minutes,
                e.type_examen,
                e.statut,
                COUNT(DISTINCT i.etudiant_id) as nb_etudiants,
                COUNT(DISTINCT s.id) as nb_surveillants
            FROM gestion_examens.examens e
            JOIN gestion_examens.modules m ON e.module_id = m.id
            JOIN gestion_examens.formations f ON e.formation_id = f.id
            JOIN gestion_examens.departements d ON f.dept_id = d.id
            JOIN gestion_examens.salles_examen sa ON e.salle_id = sa.id
            LEFT JOIN gestion_examens.inscriptions i ON m.id = i.module_id AND i.statut IN ('inscrit', 'en_cours')
            LEFT JOIN gestion_examens.surveillances s ON e.id = s.examen_id
            WHERE e.professeur_responsable_id = %s
            GROUP BY e.id, m.nom, m.code, f.nom, d.nom, sa.nom, sa.capacite, sa.type, 
                     e.date_heure, e.duree_minutes, e.type_examen, e.statut
            ORDER BY e.date_heure
        """, (prof_id,))
        
        if not df_examens_responsable.empty:
            # Statistiques
            col1, col2, col3 = st.columns(3)
            
            with col1:
                total_exams = len(df_examens_responsable)
                st.metric("📝 Examens responsables", total_exams)
            
            with col2:
                total_students = df_examens_responsable['nb_etudiants'].sum()
                st.metric("👨‍🎓 Étudiants concernés", total_students)
            
            with col3:
                exams_today = df_examens_responsable[
                    df_examens_responsable['date_examen'] == datetime.now().strftime('%d/%m/%Y')
                ].shape[0]
                st.metric("📅 Aujourd'hui", exams_today)
            
            st.markdown("---")
            
            # Afficher chaque examen
            for idx, exam in df_examens_responsable.iterrows():
                with st.expander(
                    f"{exam['module']} - {exam['date_examen']} {exam['heure_examen']} ({exam['statut']})", 
                    expanded=False
                ):
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.markdown(f"""
                        **📚 Module:** {exam['module']} ({exam['code_module']})
                        
                        **🎓 Formation:** {exam['formation']}
                        
                        **🏛️ Département:** {exam['departement']}
                        
                        **📝 Type:** {exam['type_examen']}
                        
                        **📊 Statut:** {exam['statut']}
                        """)
                    
                    with col2:
                        st.markdown(f"""
                        **🏢 Salle:** {exam['salle']} ({exam['type_salle']})
                        
                        **👥 Capacité:** {exam['capacite']} places
                        
                        **👨‍🎓 Étudiants inscrits:** {exam['nb_etudiants']}
                        
                        **👁️ Surveillants:** {exam['nb_surveillants']}
                        
                        **⏱️ Durée:** {exam['duree_minutes']} minutes
                        
                        **📅 Date:** {exam['date_examen']}
                        
                        **🕐 Heure:** {exam['heure_examen']}
                        """)
                    
                    # Actions pour le responsable
                    st.markdown("### 🛠️ Actions du responsable")
                    
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        if st.button("📄 Voir la liste des étudiants", key=f"list_{exam['id']}"):
                            st.info(f"Liste des {exam['nb_etudiants']} étudiants pour {exam['module']}")
                            # Ici, normalement, on afficherait la liste
                    
                    with col2:
                        if st.button("👁️ Voir les surveillants", key=f"surv_{exam['id']}"):
                            st.info(f"Liste des {exam['nb_surveillants']} surveillants")
                            # Ici, normalement, on afficherait la liste
                    
                    with col3:
                        if st.button("📝 Saisir les notes", key=f"notes_{exam['id']}"):
                            st.info("Interface de saisie des notes")
                            # Ici, normalement, on ouvrirait l'interface de saisie
            
            # Graphique des examens par mois
            st.markdown("---")
            st.subheader("📈 Calendrier des examens responsables")
            
            # Préparer les données
            df_calendar = df_examens_responsable.copy()
            df_calendar['date'] = pd.to_datetime(df_calendar['date_heure'])
            df_calendar['mois'] = df_calendar['date'].dt.strftime('%Y-%m')
            df_calendar['count'] = 1
            
            exams_par_mois = df_calendar.groupby('mois').agg({
                'count': 'sum',
                'nb_etudiants': 'sum'
            }).reset_index()
            
            fig = px.bar(
                exams_par_mois,
                x='mois',
                y='count',
                title='Nombre d\'examens par mois',
                color='nb_etudiants',
                color_continuous_scale='Plasma',
                hover_data=['nb_etudiants']
            )
            st.plotly_chart(fig, use_container_width=True)
        
        else:
            st.info("📭 Aucun examen en tant que responsable pour le moment")
    
    except Exception as e:
        st.error(f"Erreur: {e}")

# ============================================
# TAB 3: STATISTIQUES
# ============================================
with tab3:
    st.header("📊 Mes Statistiques")
    
    try:
        # Récupérer les statistiques du professeur
        df_stats = db.execute_query("""
            SELECT 
                p.matricule,
                p.nom,
                p.prenom,
                p.specialite,
                p.total_surveillances,
                p.charge_max_examens,
                d.nom as departement,
                COUNT(DISTINCT e.id) as nb_examens_responsable,
                COUNT(DISTINCT s.id) as nb_surveillances_attribuees,
                COALESCE(SUM(s.heures_creditees), 0) as total_heures_creditees
            FROM gestion_examens.professeurs p
            JOIN gestion_examens.departements d ON p.dept_id = d.id
            LEFT JOIN gestion_examens.examens e ON p.id = e.professeur_responsable_id
            LEFT JOIN gestion_examens.surveillances s ON p.id = s.professeur_id
            WHERE p.id = %s
            GROUP BY p.id, p.matricule, p.nom, p.prenom, p.specialite, 
                     p.total_surveillances, p.charge_max_examens, d.nom
        """, (prof_id,))
        
        if not df_stats.empty:
            stats = df_stats.iloc[0]
            
            st.markdown("""
            <div class="stats-card">
                <h2 style="margin-top: 0; color: #8B5CF6;">👨‍🏫 {prenom} {nom}</h2>
                <p><strong>Matricule:</strong> {matricule}</p>
                <p><strong>Spécialité:</strong> {specialite}</p>
                <p><strong>Département:</strong> {departement}</p>
            </div>
            """.format(
                prenom=stats['prenom'],
                nom=stats['nom'],
                matricule=stats['matricule'],
                specialite=stats['specialite'],
                departement=stats['departement']
            ), unsafe_allow_html=True)
            
            st.markdown("---")
            
            # Indicateurs de performance
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("👑 Examens responsables", stats['nb_examens_responsable'])
            
            with col2:
                st.metric("👁️ Surveillances attribuées", stats['nb_surveillances_attribuees'])
            
            with col3:
                st.metric("⏱️ Heures créditées total", f"{stats['total_heures_creditees']:.1f}h")
            
            with col4:
                charge_actuelle = stats['total_surveillances']
                charge_max = stats['charge_max_examens']
                taux_charge = (charge_actuelle / charge_max * 100) if charge_max > 0 else 0
                st.metric("📊 Taux de charge", f"{taux_charge:.1f}%")
            
            # Graphiques
            st.markdown("---")
            st.subheader("📈 Évolution de la charge")
            
            try:
                # Récupérer l'historique des surveillances
                df_historique = db.execute_query("""
                    SELECT 
                        DATE(e.date_heure) as date_examen,
                        COUNT(s.id) as nb_surveillances,
                        SUM(s.heures_creditees) as heures_creditees
                    FROM gestion_examens.surveillances s
                    JOIN gestion_examens.examens e ON s.examen_id = e.id
                    WHERE s.professeur_id = %s
                    GROUP BY DATE(e.date_heure)
                    ORDER BY DATE(e.date_heure)
                """, (prof_id,))
                
                if not df_historique.empty:
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        fig = px.line(
                            df_historique,
                            x='date_examen',
                            y='nb_surveillances',
                            title='Nombre de surveillances par jour',
                            markers=True
                        )
                        st.plotly_chart(fig, use_container_width=True)
                    
                    with col2:
                        fig = px.area(
                            df_historique,
                            x='date_examen',
                            y='heures_creditees',
                            title='Heures créditées cumulées',
                            fill='tozeroy'
                        )
                        st.plotly_chart(fig, use_container_width=True)
                
            except:
                st.info("Historique non disponible")
            
            # Comparaison avec les collègues
            st.markdown("---")
            st.subheader("📊 Comparaison départementale")
            
            try:
                df_comparaison = db.execute_query("""
                    SELECT 
                        p.prenom || ' ' || p.nom as nom_professeur,
                        p.total_surveillances,
                        COUNT(DISTINCT s.id) as nb_surveillances_attribuees
                    FROM gestion_examens.professeurs p
                    LEFT JOIN gestion_examens.surveillances s ON p.id = s.professeur_id
                    WHERE p.dept_id = %s AND p.statut = 'actif'
                    GROUP BY p.id, p.prenom, p.nom, p.total_surveillances
                    ORDER BY p.total_surveillances DESC
                """, (prof_dept,))
                
                if not df_comparaison.empty:
                    # Mettre en évidence le professeur actuel
                    df_comparaison['est_moi'] = df_comparaison['nom_professeur'] == f"{stats['prenom']} {stats['nom']}"
                    
                    fig = px.bar(
                        df_comparaison,
                        x='nom_professeur',
                        y='total_surveillances',
                        title='Charge de surveillances dans le département',
                        color='est_moi',
                        color_discrete_map={True: '#8B5CF6', False: '#D1D5DB'},
                        text='total_surveillances'
                    )
                    fig.update_traces(texttemplate='%{text}', textposition='outside')
                    st.plotly_chart(fig, use_container_width=True)
            
            except:
                st.info("Comparaison non disponible")
        
        else:
            st.error("Statistiques non disponibles")
    
    except Exception as e:
        st.error(f"Erreur: {e}")

# ============================================
# TAB 4: MODULES
# ============================================
with tab4:
    st.header("📚 Mes Modules d'Enseignement")
    
    try:
        # Récupérer les modules enseignés par le professeur
        df_modules = db.execute_query("""
            SELECT DISTINCT
                m.id,
                m.nom as module,
                m.code as code_module,
                m.credits,
                f.nom as formation,
                d.nom as departement,
                COUNT(DISTINCT i.etudiant_id) as nb_etudiants_inscrits,
                COUNT(DISTINCT e.id) as nb_examens_planifies
            FROM gestion_examens.modules m
            JOIN gestion_examens.formations f ON m.formation_id = f.id
            JOIN gestion_examens.departements d ON f.dept_id = d.id
            LEFT JOIN gestion_examens.inscriptions i ON m.id = i.module_id AND i.statut IN ('inscrit', 'en_cours')
            LEFT JOIN gestion_examens.examens e ON m.id = e.module_id AND e.professeur_responsable_id = %s
            WHERE EXISTS (
                SELECT 1 FROM gestion_examens.examens ex
                WHERE ex.module_id = m.id AND ex.professeur_responsable_id = %s
            )
            GROUP BY m.id, m.nom, m.code, m.credits, f.nom, d.nom
            ORDER BY m.nom
        """, (prof_id, prof_id))
        
        if not df_modules.empty:
            # Statistiques des modules
            col1, col2, col3 = st.columns(3)
            
            with col1:
                total_modules = len(df_modules)
                st.metric("📚 Modules enseignés", total_modules)
            
            with col2:
                total_students = df_modules['nb_etudiants_inscrits'].sum()
                st.metric("👨‍🎓 Étudiants total", total_students)
            
            with col3:
                total_exams = df_modules['nb_examens_planifies'].sum()
                st.metric("📝 Examens planifiés", total_exams)
            
            st.markdown("---")
            
            # Afficher chaque module
            for idx, module in df_modules.iterrows():
                with st.expander(f"{module['module']} ({module['code_module']})", expanded=False):
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.markdown(f"""
                        **📚 Module:** {module['module']}
                        
                        **🔢 Code:** {module['code_module']}
                        
                        **🎓 Formation:** {module['formation']}
                        
                        **🏛️ Département:** {module['departement']}
                        
                        **🎯 Crédits:** {module['credits']}
                        """)
                    
                    with col2:
                        st.markdown(f"""
                        **👨‍🎓 Étudiants inscrits:** {module['nb_etudiants_inscrits']}
                        
                        **📝 Examens planifiés:** {module['nb_examens_planifies']}
                        
                        **📊 Taux de réussite:** À calculer
                        
                        **📈 Moyenne générale:** À calculer
                        """)
                    
                    # Actions pour le module
                    st.markdown("### 🛠️ Actions pédagogiques")
                    
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        if st.button("📋 Voir la liste des étudiants", key=f"etud_{module['id']}"):
                            st.info(f"Liste des étudiants pour {module['module']}")
                    
                    with col2:
                        if st.button("📊 Statistiques du module", key=f"stats_{module['id']}"):
                            st.info(f"Statistiques détaillées pour {module['module']}")
                    
                    with col3:
                        if st.button("📁 Documents pédagogiques", key=f"docs_{module['id']}"):
                            st.info(f"Documents pour {module['module']}")
            
            # Graphique des modules
            st.markdown("---")
            st.subheader("📊 Répartition des étudiants par module")
            
            fig = px.pie(
                df_modules,
                values='nb_etudiants_inscrits',
                names='module',
                title='Nombre d\'étudiants par module',
                hole=0.4
            )
            st.plotly_chart(fig, use_container_width=True)
        
        else:
            st.info("📭 Aucun module d'enseignement trouvé")
            st.markdown("""
            <div class="stats-card">
                <h4 style="margin-top: 0;">ℹ️ Information</h4>
                <p>Vous n'êtes actuellement responsable d'aucun module d'enseignement.</p>
                <p>Pour être assigné à des modules, contactez votre chef de département.</p>
            </div>
            """, unsafe_allow_html=True)
    
    except Exception as e:
        st.error(f"Erreur: {e}")

# ============================================
# PIED DE PAGE
# ============================================
st.markdown("---")
st.markdown("""
<div style="text-align: center; color: #6B7280; padding: 1rem;">
    👨‍🏫 <strong>Espace Professeur</strong> | 
    Plateforme d'Optimisation des Examens Universitaires | 
    © 2025
</div>
""", unsafe_allow_html=True)

# Bouton de retour
if st.sidebar.button("🏠 Retour à l'accueil"):
    st.switch_page("app.py")