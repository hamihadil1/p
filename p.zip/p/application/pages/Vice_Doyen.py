# pages/Vice_Doyen.py
# Vue stratégique globale - Vice-Doyen

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
from database import db


# =========================
# Configuration de la page
# =========================
st.set_page_config(
    page_title="Vice-Doyen",
    page_icon="👑",
    layout="wide"
)

st.markdown(
    '<h1 style="color:#1E3A8A; text-align:center;">👑 Tableau de bord du Vice-Doyen</h1>',
    unsafe_allow_html=True
)

# =========================
# Barre latérale - Navigation
# =========================
st.sidebar.header("📊 Tableau de bord")

option = st.sidebar.radio(
    "Choisissez la vue :",
    [
        "📈 Vue d’ensemble",
        "🏢 Utilisation des salles",
        "📊 Statistiques",
        "⚠️ Conflits"
    ]
)

# =========================================================
# 📈 VUE D’ENSEMBLE
# =========================================================
if option == "📈 Vue d’ensemble":
    st.header("📊 Indicateurs stratégiques (KPIs)")

    try:
        kpis_query = """
            SELECT 
                'Étudiants actifs' AS indicateur,
                COUNT(*)::text AS valeur
            FROM gestion_examens.etudiants 
            WHERE statut = 'actif'

            UNION ALL
            SELECT 
                'Examens planifiés',
                COUNT(*)::text
            FROM gestion_examens.examens 
            WHERE statut = 'planifie'

            UNION ALL
            SELECT 
                'Taux d’utilisation des salles (%)',
                ROUND(
                    COUNT(DISTINCT salle_id) * 100.0 /
                    (SELECT COUNT(*) FROM gestion_examens.salles_examen),
                1)::text
            FROM gestion_examens.examens 
            WHERE statut = 'planifie'

            UNION ALL
            SELECT 
                'Conflits détectés',
                COUNT(*)::text
            FROM gestion_examens.vue_conflits
        """

        df_kpis = db.execute_query(kpis_query)

        cols = st.columns(4)
        for i, row in df_kpis.iterrows():
            cols[i].metric(row["indicateur"], row["valeur"])

        st.markdown("---")

        # =========================
        # Utilisation des salles par département
        # =========================
        st.subheader("🏢 Utilisation des salles par département")

        occupation_query = """
            SELECT 
                d.nom AS departement,
                COUNT(DISTINCT f.id) AS nb_formations,
                COUNT(DISTINCT e.id) AS nb_etudiants,
                COUNT(DISTINCT ex.id) AS nb_examens
            FROM gestion_examens.departements d
            LEFT JOIN gestion_examens.formations f ON d.id = f.dept_id
            LEFT JOIN gestion_examens.etudiants e 
                ON f.id = e.formation_id AND e.statut = 'actif'
            LEFT JOIN gestion_examens.examens ex 
                ON f.id = ex.formation_id AND ex.statut = 'planifie'
            GROUP BY d.id, d.nom
            ORDER BY nb_etudiants DESC
        """

        df_occ = db.execute_query(occupation_query)

        if not df_occ.empty:
            col1, col2 = st.columns(2)

            with col1:
                fig = px.pie(
                    df_occ,
                    values="nb_etudiants",
                    names="departement",
                    title="Répartition des étudiants par département"
                )
                st.plotly_chart(fig, use_container_width=True)

            with col2:
                fig = px.bar(
                    df_occ,
                    x="departement",
                    y="nb_examens",
                    title="Nombre d’examens par département",
                    color="nb_examens"
                )
                st.plotly_chart(fig, use_container_width=True)

            st.dataframe(
                df_occ.style.background_gradient(
                    subset=["nb_etudiants", "nb_examens"],
                    cmap="Blues"
                )
            )

    except Exception as e:
        st.error(f"Erreur lors du chargement des données : {e}")

# =========================================================
# 🏢 UTILISATION DES SALLES
# =========================================================
elif option == "🏢 Utilisation des salles":
    st.header("🏢 Analyse de l’utilisation des salles")

    try:
        salles_query = """
            SELECT 
                type,
                COUNT(*) AS total,
                COUNT(CASE WHEN disponible = true THEN 1 END) AS disponibles,
                COUNT(CASE WHEN disponible = false THEN 1 END) AS occupees,
                ROUND(
                    COUNT(CASE WHEN disponible = false THEN 1 END) * 100.0 / COUNT(*),
                1) AS taux_occupation
            FROM gestion_examens.salles_examen
            GROUP BY type
            ORDER BY type
        """

        df_salles = db.execute_query(salles_query)

        if not df_salles.empty:
            col1, col2 = st.columns(2)

            with col1:
                fig = px.pie(
                    df_salles,
                    values="total",
                    names="type",
                    title="Types de salles"
                )
                st.plotly_chart(fig, use_container_width=True)

            with col2:
                fig = px.bar(
                    df_salles,
                    x="type",
                    y="taux_occupation",
                    title="Taux d’occupation des salles (%)",
                    color="taux_occupation",
                    color_continuous_scale="Viridis"
                )
                st.plotly_chart(fig, use_container_width=True)

            st.dataframe(
                df_salles.style.format({"taux_occupation": "{:.1f} %"})
            )

        st.markdown("---")
        st.subheader("📅 Salles occupées aujourd’hui")

        salles_occupees_query = """
            SELECT 
                s.nom AS salle,
                s.type,
                s.capacite,
                m.nom AS module,
                f.nom AS formation,
                TO_CHAR(e.date_heure, 'HH24:MI') AS heure,
                e.duree_minutes
            FROM gestion_examens.examens e
            JOIN gestion_examens.salles_examen s ON e.salle_id = s.id
            JOIN gestion_examens.modules m ON e.module_id = m.id
            JOIN gestion_examens.formations f ON e.formation_id = f.id
            WHERE DATE(e.date_heure) = CURRENT_DATE
            AND e.statut IN ('planifie', 'confirme')
            ORDER BY e.date_heure
        """

        df_occ_today = db.execute_query(salles_occupees_query)

        if not df_occ_today.empty:
            st.dataframe(df_occ_today)
        else:
            st.info("Aucune salle occupée aujourd’hui")

    except Exception as e:
        st.error(f"Erreur : {e}")

# =========================================================
# 📊 STATISTIQUES
# =========================================================
elif option == "📊 Statistiques":
    st.header("📈 Statistiques détaillées")

    try:
        st.subheader("👨‍🏫 Statistiques des professeurs")

        profs_query = """
            SELECT 
                d.nom AS departement,
                COUNT(p.id) AS nb_professeurs,
                SUM(p.total_surveillances) AS total_surveillances,
                ROUND(AVG(p.total_surveillances), 1) AS moyenne_surveillances
            FROM gestion_examens.professeurs p
            JOIN gestion_examens.departements d ON p.dept_id = d.id
            WHERE p.statut = 'actif'
            GROUP BY d.nom
            ORDER BY nb_professeurs DESC
        """

        df_profs = db.execute_query(profs_query)

        if not df_profs.empty:
            col1, col2 = st.columns(2)

            with col1:
                fig = px.bar(
                    df_profs,
                    x="departement",
                    y="nb_professeurs",
                    title="Nombre de professeurs par département",
                    color="nb_professeurs"
                )
                st.plotly_chart(fig, use_container_width=True)

            with col2:
                fig = px.scatter(
                    df_profs,
                    x="nb_professeurs",
                    y="moyenne_surveillances",
                    size="total_surveillances",
                    color="departement",
                    title="Charge de surveillance des professeurs"
                )
                st.plotly_chart(fig, use_container_width=True)

        st.markdown("---")
        st.subheader("👨‍🎓 Statistiques des étudiants")

        etudiants_query = """
            SELECT 
                f.nom AS formation,
                d.nom AS departement,
                COUNT(e.id) AS nb_etudiants,
                ROUND(AVG(i.note)::NUMERIC, 2) AS moyenne_notes
            FROM gestion_examens.etudiants e
            JOIN gestion_examens.formations f ON e.formation_id = f.id
            JOIN gestion_examens.departements d ON f.dept_id = d.id
            LEFT JOIN gestion_examens.inscriptions i ON e.id = i.etudiant_id
            WHERE e.statut = 'actif'
            GROUP BY f.id, f.nom, d.id, d.nom
            ORDER BY nb_etudiants DESC
            LIMIT 10
        """

        df_etud = db.execute_query(etudiants_query)
        st.dataframe(
            df_etud.style.background_gradient(
                subset=["moyenne_notes"],
                cmap="RdYlGn"
            )
        )

    except Exception as e:
        st.error(f"Erreur : {e}")

# =========================================================
# ⚠️ CONFLITS
# =========================================================
elif option == "⚠️ Conflits":
    st.header("⚠️ Rapport des conflits")

    try:
        conflits_query = """
            SELECT 
                type_conflit,
                COUNT(*) AS nombre,
                STRING_AGG(DISTINCT element, ', ') AS elements_concernes
            FROM gestion_examens.vue_conflits
            GROUP BY type_conflit
            ORDER BY nombre DESC
        """

        df_conflits = db.execute_query(conflits_query)

        if not df_conflits.empty:
            col1, col2 = st.columns(2)

            with col1:
                fig = px.bar(
                    df_conflits,
                    x="type_conflit",
                    y="nombre",
                    title="Conflits par type",
                    color="nombre",
                    color_continuous_scale="Reds"
                )
                st.plotly_chart(fig, use_container_width=True)

            with col2:
                st.subheader("📋 Détails")
                for _, row in df_conflits.iterrows():
                    with st.expander(f"{row['type_conflit']} ({row['nombre']})"):
                        st.write(row["elements_concernes"])

            st.markdown("---")
            st.subheader("🔍 Derniers conflits détectés")

            df_details = db.execute_query("""
                SELECT *
                FROM gestion_examens.vue_conflits
                ORDER BY date_conflit DESC
                LIMIT 20
            """)
            st.dataframe(df_details)

        else:
            st.success("🎉 Aucun conflit détecté")

    except Exception as e:
        st.error(f"Erreur : {e}")

# =========================
# Retour à l'accueil
# =========================
st.sidebar.markdown("---")
if st.sidebar.button("🏠 Retour à l’accueil"):
    st.switch_page("app.py")
