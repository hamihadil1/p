# 3_📊_Chef_Departement.py - صفحة رئيس القسم
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
from database import db

# إعداد الصفحة
st.set_page_config(
    page_title="Chef de Département - Examens Universitaires",
    page_icon="📊",
    layout="wide"
)

# ============================================
# STYLES CSS
# ============================================
st.markdown("""
<style>
    .dept-header {
        font-size: 2.5rem;
        background: linear-gradient(90deg, #10B981, #3B82F6);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-align: center;
        margin-bottom: 1rem;
    }
    .stat-card {
        background: white;
        padding: 1.5rem;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        border-left: 5px solid #10B981;
        margin-bottom: 1rem;
    }
    .warning-card {
        border-left: 5px solid #F59E0B;
    }
    .critical-card {
        border-left: 5px solid #EF4444;
    }
</style>
""", unsafe_allow_html=True)

# ============================================
# PAGE TITLE
# ============================================
st.markdown('<h1 class="dept-header">📊 Tableau de Bord - Chef de Département</h1>', unsafe_allow_html=True)

# ============================================
# SIDEBAR - Sélection du département
# ============================================
st.sidebar.header("🔧 Configuration")

# Récupérer la liste des départements
try:
    df_departements = db.execute_query("""
        SELECT id, nom 
        FROM gestion_examens.departements 
        ORDER BY nom
    """)
    
    if df_departements.empty:
        departements = [("1", "Informatique")]
    else:
        departements = [(str(row['id']), row['nom']) for _, row in df_departements.iterrows()]
    
except:
    departements = [
        ("1", "Informatique"),
        ("2", "Mathématiques"), 
        ("3", "Physique"),
        ("4", "Chimie"),
        ("5", "Biologie"),
        ("6", "Langues"),
        ("7", "Droit")
    ]

# Sélecteur de département
selected_dept = st.sidebar.selectbox(
    "Sélectionnez votre département",
    options=[d[1] for d in departements],
    index=0
)

# Récupérer l'ID du département sélectionné
dept_id = next((d[0] for d in departements if d[1] == selected_dept), "1")

# ============================================
# ONGLETS PRINCIPAUX
# ============================================
tab1, tab2, tab3, tab4 = st.tabs([
    "📈 Statistiques", 
    "📅 Examens", 
    "⚠️ Conflits", 
    "👥 Ressources"
])

# ============================================
# TAB 1: STATISTIQUES
# ============================================
with tab1:
    st.header(f"📊 Statistiques du Département: {selected_dept}")
    
    try:
        # KPIs pour le département
        col1, col2, col3, col4 = st.columns(4)
        
        # Nombre d'étudiants
        df_etudiants = db.execute_query("""
            SELECT COUNT(*) as nb
            FROM gestion_examens.etudiants e
            JOIN gestion_examens.formations f ON e.formation_id = f.id
            WHERE f.dept_id = %s AND e.statut = 'actif'
        """, (dept_id,))
        
        with col1:
            if not df_etudiants.empty:
                st.metric("👨‍🎓 Étudiants", df_etudiants['nb'].iloc[0])
            else:
                st.metric("👨‍🎓 Étudiants", 0)
        
        # Nombre de professeurs
        df_professeurs = db.execute_query("""
            SELECT COUNT(*) as nb
            FROM gestion_examens.professeurs 
            WHERE dept_id = %s AND statut = 'actif'
        """, (dept_id,))
        
        with col2:
            if not df_professeurs.empty:
                st.metric("👨‍🏫 Professeurs", df_professeurs['nb'].iloc[0])
            else:
                st.metric("👨‍🏫 Professeurs", 0)
        
        # Nombre d'examens planifiés
        df_examens = db.execute_query("""
            SELECT COUNT(*) as nb
            FROM gestion_examens.examens e
            JOIN gestion_examens.formations f ON e.formation_id = f.id
            WHERE f.dept_id = %s AND e.statut = 'planifie'
        """, (dept_id,))
        
        with col3:
            if not df_examens.empty:
                st.metric("📝 Examens", df_examens['nb'].iloc[0])
            else:
                st.metric("📝 Examens", 0)
        
        # Taux de réussite
        df_reussite = db.execute_query("""
            SELECT 
                ROUND(AVG(CASE WHEN i.note >= 10 THEN 1 ELSE 0 END) * 100, 1) as taux_reussite
            FROM gestion_examens.inscriptions i
            JOIN gestion_examens.etudiants e ON i.etudiant_id = e.id
            JOIN gestion_examens.formations f ON e.formation_id = f.id
            WHERE f.dept_id = %s AND i.note IS NOT NULL
        """, (dept_id,))
        
        with col4:
            if not df_reussite.empty and df_reussite['taux_reussite'].iloc[0] is not None:
                st.metric("📈 Taux Réussite", f"{df_reussite['taux_reussite'].iloc[0]}%")
            else:
                st.metric("📈 Taux Réussite", "N/A")
        
        st.markdown("---")
        
        # Graphique: Répartition par formation
        st.subheader("📚 Répartition par formation")
        
        df_formations = db.execute_query("""
            SELECT 
                f.nom as formation,
                COUNT(DISTINCT e.id) as nb_etudiants,
                COUNT(DISTINCT ex.id) as nb_examens,
                ROUND(AVG(i.note), 2) as moyenne_notes
            FROM gestion_examens.formations f
            LEFT JOIN gestion_examens.etudiants e ON f.id = e.formation_id AND e.statut = 'actif'
            LEFT JOIN gestion_examens.examens ex ON f.id = ex.formation_id AND ex.statut = 'planifie'
            LEFT JOIN gestion_examens.inscriptions i ON e.id = i.etudiant_id
            WHERE f.dept_id = %s
            GROUP BY f.id, f.nom
            ORDER BY nb_etudiants DESC
        """, (dept_id,))
        
        if not df_formations.empty:
            col1, col2 = st.columns(2)
            
            with col1:
                # Diagramme à barres
                fig = px.bar(
                    df_formations,
                    x='formation',
                    y='nb_etudiants',
                    title='Nombre d\'étudiants par formation',
                    color='nb_etudiants',
                    color_continuous_scale='Viridis'
                )
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                # Diagramme circulaire des examens
                fig = px.pie(
                    df_formations,
                    values='nb_examens',
                    names='formation',
                    title='Répartition des examens'
                )
                st.plotly_chart(fig, use_container_width=True)
            
            # Tableau détaillé
            st.dataframe(
                df_formations.style.background_gradient(
                    subset=['moyenne_notes'], 
                    cmap='RdYlGn'
                ).format({'moyenne_notes': '{:.2f}'})
            )
        
    except Exception as e:
        st.error(f"Erreur lors du chargement des statistiques: {e}")

# ============================================
# TAB 2: EXAMENS
# ============================================
with tab2:
    st.header(f"📅 Examens du Département: {selected_dept}")
    
    try:
        # Filtres de date
        col1, col2 = st.columns(2)
        
        with col1:
            date_debut = st.date_input("Date de début", datetime.now())
        
        with col2:
            date_fin = st.date_input("Date de fin", datetime.now())
        
        # Liste des examens
        df_examens = db.execute_query("""
            SELECT 
                e.id,
                m.nom as module,
                f.nom as formation,
                p.prenom || ' ' || p.nom as professeur,
                s.nom as salle,
                TO_CHAR(e.date_heure, 'DD/MM/YYYY HH24:MI') as date_heure,
                e.duree_minutes,
                e.statut,
                COUNT(sv.id) as nb_surveillants
            FROM gestion_examens.examens e
            JOIN gestion_examens.modules m ON e.module_id = m.id
            JOIN gestion_examens.formations f ON e.formation_id = f.id
            JOIN gestion_examens.professeurs p ON e.professeur_responsable_id = p.id
            JOIN gestion_examens.salles_examen s ON e.salle_id = s.id
            LEFT JOIN gestion_examens.surveillances sv ON e.id = sv.examen_id
            WHERE f.dept_id = %s 
            AND DATE(e.date_heure) BETWEEN %s AND %s
            AND e.statut IN ('planifie', 'confirme')
            GROUP BY e.id, m.nom, f.nom, p.prenom, p.nom, s.nom, e.date_heure, e.duree_minutes, e.statut
            ORDER BY e.date_heure
        """, (dept_id, date_debut, date_fin))
        
        if not df_examens.empty:
            # Statistiques des examens
            st.subheader(f"📋 {len(df_examens)} examens trouvés")
            
            # Visualisation calendrier
            df_calendar = df_examens.copy()
            df_calendar['date'] = pd.to_datetime(df_calendar['date_heure'].str.split().str[0], format='%d/%m/%Y')
            df_calendar['count'] = 1
            
            fig = px.density_heatmap(
                df_calendar,
                x='date',
                y='formation',
                title='Calendrier des examens par formation',
                color_continuous_scale='Viridis'
            )
            st.plotly_chart(fig, use_container_width=True)
            
            # Liste détaillée
            st.subheader("📋 Liste détaillée")
            
            # Options de filtrage
            col1, col2 = st.columns(2)
            with col1:
                formation_filter = st.selectbox(
                    "Filtrer par formation",
                    ["Toutes"] + df_examens['formation'].unique().tolist()
                )
            
            with col2:
                statut_filter = st.selectbox(
                    "Filtrer par statut",
                    ["Tous"] + df_examens['statut'].unique().tolist()
                )
            
            # Appliquer les filtres
            filtered_df = df_examens.copy()
            if formation_filter != "Toutes":
                filtered_df = filtered_df[filtered_df['formation'] == formation_filter]
            if statut_filter != "Tous":
                filtered_df = filtered_df[filtered_df['statut'] == statut_filter]
            
            st.dataframe(filtered_df)
            
            # Bouton d'export
            if st.button("📥 Exporter en CSV"):
                csv = filtered_df.to_csv(index=False)
                st.download_button(
                    label="Télécharger CSV",
                    data=csv,
                    file_name=f"examens_{selected_dept}_{datetime.now().strftime('%Y%m%d')}.csv",
                    mime="text/csv"
                )
        else:
            st.info("Aucun examen trouvé pour la période sélectionnée")
    
    except Exception as e:
        st.error(f"Erreur: {e}")

# ============================================
# TAB 3: CONFLITS
# ============================================
with tab3:
    st.header(f"⚠️ Conflits du Département: {selected_dept}")
    
    try:
        # Conflits spécifiques au département
        df_conflits = db.execute_query("""
            SELECT 
                vc.*,
                d.nom as departement
            FROM gestion_examens.vue_conflits vc
            JOIN gestion_examens.etudiants e ON vc.element LIKE '%' || e.nom || '%'
            JOIN gestion_examens.formations f ON e.formation_id = f.id
            JOIN gestion_examens.departements d ON f.dept_id = d.id
            WHERE d.id = %s
            ORDER BY vc.date_conflit DESC
        """, (dept_id,))
        
        if not df_conflits.empty:
            st.warning(f"⚠️ {len(df_conflits)} conflits détectés")
            
            # Analyse par type de conflit
            st.subheader("📊 Analyse des conflits")
            
            df_types = df_conflits.groupby('type_conflit').size().reset_index(name='count')
            
            col1, col2 = st.columns(2)
            
            with col1:
                fig = px.pie(
                    df_types,
                    values='count',
                    names='type_conflit',
                    title='Répartition des types de conflits'
                )
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                fig = px.bar(
                    df_types,
                    x='type_conflit',
                    y='count',
                    title='Nombre de conflits par type',
                    color='count',
                    color_continuous_scale='Reds'
                )
                st.plotly_chart(fig, use_container_width=True)
            
            # Liste détaillée des conflits
            st.subheader("🔍 Détails des conflits")
            
            for _, conflit in df_conflits.iterrows():
                with st.expander(f"{conflit['type_conflit']} - {conflit['element']}", expanded=True):
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.write(f"**Élément concerné:** {conflit['element']}")
                        st.write(f"**Date:** {conflit['date_conflit']}")
                        st.write(f"**Nombre d'examens:** {conflit['nombre_examens']}")
                    
                    with col2:
                        # Boutons d'action
                        if st.button("🔄 Réaffecter", key=f"reaffect_{conflit['element']}"):
                            st.info("Réaffectation en cours...")
                            # Logique de réaffectation
                        
                        if st.button("📅 Replanifier", key=f"replan_{conflit['element']}"):
                            st.info("Replanification en cours...")
                            # Logique de replanification
            
            # Recommandations automatiques
            st.subheader("💡 Recommandations")
            
            recommendations = []
            
            if len(df_conflits) > 5:
                recommendations.append("📊 **Nombre élevé de conflits:** Considérez une révision complète de l'emploi du temps")
            
            conflits_salle = df_conflits[df_conflits['type_conflit'].str.contains('salle', case=False)]
            if len(conflits_salle) > 0:
                recommendations.append("🏢 **Conflits de salles:** Vérifiez la disponibilité des amphis pour les gros effectifs")
            
            conflits_profs = df_conflits[df_conflits['type_conflit'].str.contains('professeur', case=False)]
            if len(conflits_profs) > 0:
                recommendations.append("👨‍🏫 **Surcharge de professeurs:** Distribuez mieux les surveillances")
            
            for rec in recommendations:
                st.info(rec)
        
        else:
            st.success("✅ Aucun conflit détecté dans votre département!")
    
    except Exception as e:
        st.error(f"Erreur: {e}")

# ============================================
# TAB 4: RESSOURCES
# ============================================
with tab4:
    st.header(f"👥 Ressources du Département: {selected_dept}")
    
    try:
        col1, col2 = st.columns(2)
        
        with col1:
            # Liste des professeurs
            st.subheader("👨‍🏫 Professeurs du département")
            
            df_professeurs = db.execute_query("""
                SELECT 
                    p.id,
                    p.matricule,
                    p.nom,
                    p.prenom,
                    p.specialite,
                    p.total_surveillances,
                    p.charge_max_examens
                FROM gestion_examens.professeurs p
                WHERE p.dept_id = %s AND p.statut = 'actif'
                ORDER BY p.total_surveillances DESC
            """, (dept_id,))
            
            if not df_professeurs.empty:
                # Graphique de charge
                fig = px.bar(
                    df_professeurs,
                    x=df_professeurs['prenom'] + ' ' + df_professeurs['nom'],
                    y='total_surveillances',
                    title='Charge de surveillances par professeur',
                    color='total_surveillances',
                    color_continuous_scale='Blues'
                )
                st.plotly_chart(fig, use_container_width=True)
                
                # Tableau détaillé
                st.dataframe(
                    df_professeurs[['matricule', 'nom', 'prenom', 'specialite', 'total_surveillances']]
                    .style.background_gradient(subset=['total_surveillances'], cmap='Blues')
                )
        
        with col2:
            # Liste des salles disponibles
            st.subheader("🏢 Salles attribuées")
            
            df_salles = db.execute_query("""
                SELECT DISTINCT
                    s.nom,
                    s.type,
                    s.capacite,
                    s.batiment,
                    s.disponible
                FROM gestion_examens.salles_examen s
                JOIN gestion_examens.examens e ON s.id = e.salle_id
                JOIN gestion_examens.formations f ON e.formation_id = f.id
                WHERE f.dept_id = %s
                ORDER BY s.type, s.capacite
            """, (dept_id,))
            
            if not df_salles.empty:
                # Graphique de capacité
                fig = px.scatter(
                    df_salles,
                    x='type',
                    y='capacite',
                    size='capacite',
                    color='disponible',
                    title='Capacité des salles par type',
                    hover_name='nom'
                )
                st.plotly_chart(fig, use_container_width=True)
                
                # Indicateurs de disponibilité
                salles_dispo = df_salles[df_salles['disponible'] == True].shape[0]
                salles_total = df_salles.shape[0]
                
                st.metric("✅ Salles disponibles", salles_dispo)
                st.metric("📊 Total salles", salles_total)
                st.metric("📈 Taux disponibilité", f"{(salles_dispo/salles_total*100):.1f}%")
        
        # Section d'optimisation
        st.markdown("---")
        st.subheader("⚡ Optimisation des ressources")
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("🔄 Rééquilibrer les surveillances", use_container_width=True):
                with st.spinner("Rééquilibrage en cours..."):
                    # Logique de rééquilibrage
                    st.success("Surveillances rééquilibrées avec succès!")
        
        with col2:
            if st.button("📊 Générer rapport", use_container_width=True):
                with st.spinner("Génération du rapport..."):
                    # Logique de génération de rapport
                    st.success("Rapport généré avec succès!")
                    st.download_button(
                        "📥 Télécharger rapport",
                        "Contenu du rapport simulé",
                        file_name=f"rapport_{selected_dept}_{datetime.now().strftime('%Y%m%d')}.txt"
                    )
    
    except Exception as e:
        st.error(f"Erreur: {e}")

# ============================================
# PIED DE PAGE
# ============================================
st.markdown("---")
st.markdown("""
<div style="text-align: center; color: #6B7280; padding: 1rem;">
    📊 <strong>Tableau de Bord Chef de Département</strong> | 
    Plateforme d'Optimisation des Examens Universitaires | 
    © 2025
</div>
""", unsafe_allow_html=True)

# Bouton de retour
if st.sidebar.button("🏠 Retour à l'accueil"):
    st.switch_page("app.py")