# pages/Administrateur.py
# Tableau de bord Administrateur – Génération automatique des emplois du temps

import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
from database import db


# =========================
# Configuration de la page
# =========================
st.set_page_config(
    page_title="Administrateur",
    page_icon="⚙️",
    layout="wide"
)

st.markdown(
    '<h1 style="color:#3B82F6; text-align:center;">⚙️ Tableau de bord Administrateur</h1>',
    unsafe_allow_html=True
)

# =========================
# Barre latérale
# =========================
st.sidebar.header("🛠️ Outils administrateur")

option = st.sidebar.radio(
    "Choisissez une action :",
    [
        "📅 Gestion des examens",
        "🔍 Détection des conflits",
        "⚡ Génération automatique",
        "📊 Optimisation des ressources"
    ]
)

# =========================================================
# 📅 GESTION DES EXAMENS
# =========================================================
if option == "📅 Gestion des examens":
    st.header("📅 Gestion des examens")

    try:
        examens_query = """
            SELECT 
                e.id,
                m.nom AS module,
                f.nom AS formation,
                p.prenom || ' ' || p.nom AS professeur,
                s.nom AS salle,
                TO_CHAR(e.date_heure, 'DD/MM/YYYY HH24:MI') AS date_heure,
                e.duree_minutes,
                e.statut
            FROM gestion_examens.examens e
            JOIN gestion_examens.modules m ON e.module_id = m.id
            JOIN gestion_examens.formations f ON e.formation_id = f.id
            JOIN gestion_examens.professeurs p ON e.professeur_responsable_id = p.id
            JOIN gestion_examens.salles_examen s ON e.salle_id = s.id
            WHERE e.statut IN ('planifie', 'confirme')
            ORDER BY e.date_heure
        """

        df_examens = db.execute_query(examens_query)

        if not df_examens.empty:
            st.dataframe(df_examens)

            col1, col2 = st.columns(2)

            with col1:
                formation_filter = st.selectbox(
                    "Filtrer par formation",
                    ["Toutes"] + df_examens["formation"].unique().tolist()
                )

            with col2:
                statut_filter = st.selectbox(
                    "Filtrer par statut",
                    ["Tous"] + df_examens["statut"].unique().tolist()
                )

            if formation_filter != "Toutes":
                df_examens = df_examens[df_examens["formation"] == formation_filter]

            if statut_filter != "Tous":
                df_examens = df_examens[df_examens["statut"] == statut_filter]

            st.subheader(f"📋 Examens filtrés ({len(df_examens)})")
            st.dataframe(df_examens)

        else:
            st.info("Aucun examen planifié actuellement")

    except Exception as e:
        st.error(f"Erreur : {e}")

# =========================================================
# 🔍 DÉTECTION DES CONFLITS
# =========================================================
elif option == "🔍 Détection des conflits":
    st.header("🔍 Système automatique de détection des conflits")

    try:
        conflits_query = """
            SELECT *
            FROM gestion_examens.vue_conflits
            ORDER BY date_conflit DESC
        """

        df_conflits = db.execute_query(conflits_query)

        if not df_conflits.empty:
            st.warning(f"⚠️ {len(df_conflits)} conflits détectés")

            for type_conflit in df_conflits["type_conflit"].unique():
                df_type = df_conflits[df_conflits["type_conflit"] == type_conflit]

                with st.expander(f"{type_conflit} ({len(df_type)})", expanded=True):
                    for _, row in df_type.iterrows():
                        st.error(
                            f"**{row['element']}** – "
                            f"{row['date_conflit']} "
                            f"({row['nombre_examens']} examens)"
                        )

            st.subheader("🛠️ Options de résolution")

            col1, col2 = st.columns(2)

            with col1:
                if st.button("🔄 Réaffecter les surveillants"):
                    st.info("Réaffectation des surveillants en cours...")

            with col2:
                if st.button("📅 Reprogrammer les examens"):
                    st.info("Replanification des examens en cours...")

        else:
            st.success("✅ Aucun conflit détecté")

    except Exception as e:
        st.error(f"Erreur : {e}")

# =========================================================
# ⚡ GÉNÉRATION AUTOMATIQUE
# =========================================================
elif option == "⚡ Génération automatique":
    st.header("⚡ Génération automatique de l’emploi du temps")

    st.info("""
    ### ℹ️ Informations :
    - Génération automatique équilibrée
    - Respect des contraintes (salles, professeurs, étudiants)
    - Temps d’exécution estimé : < 45 secondes
    """)

    col1, col2 = st.columns(2)

    with col1:
        date_debut = st.date_input(
            "Date de début",
            datetime.now() + timedelta(days=7)
        )
        duree_session = st.slider(
            "Durée de la session (jours)",
            1, 15, 10
        )

    with col2:
        heure_debut = st.selectbox(
            "Heure de début",
            ["08:00", "09:00", "10:00", "14:00", "15:00"]
        )
        heure_fin = st.selectbox(
            "Heure de fin",
            ["12:00", "13:00", "16:00", "17:00", "18:00"]
        )

    if st.button("🚀 Lancer la génération", type="primary"):
        with st.spinner("🔄 Génération de l’emploi du temps en cours..."):
            try:
                success = db.execute_procedure(
                    "generer_emploi_du_temps_complet"
                )

                if success:
                    st.success("✅ Emploi du temps généré avec succès")

                    result_query = """
                        SELECT 
                            COUNT(*) AS nb_examens,
                            COUNT(DISTINCT salle_id) AS nb_salles,
                            COUNT(DISTINCT professeur_responsable_id) AS nb_professeurs
                        FROM gestion_examens.examens
                        WHERE statut = 'planifie'
                    """

                    df_result = db.execute_query(result_query)

                    st.metric(
                        "Examens générés",
                        df_result["nb_examens"].iloc[0]
                    )

                else:
                    st.error("❌ Échec de la génération")

            except Exception as e:
                st.error(f"Erreur : {e}")

# =========================================================
# 📊 OPTIMISATION DES RESSOURCES
# =========================================================
elif option == "📊 Optimisation des ressources":
    st.header("📊 Analyse et optimisation des ressources")

    try:
        ressources_query = """
            SELECT 
                'Salles' AS ressource,
                COUNT(*) AS total,
                COUNT(CASE WHEN disponible THEN 1 END) AS disponibles,
                COUNT(CASE WHEN NOT disponible THEN 1 END) AS occupees,
                ROUND(
                    COUNT(CASE WHEN NOT disponible THEN 1 END) * 100.0 / COUNT(*),
                1) AS taux
            FROM gestion_examens.salles_examen

            UNION ALL

            SELECT 
                'Professeurs',
                COUNT(*),
                COUNT(CASE WHEN total_surveillances < 5 THEN 1 END),
                COUNT(CASE WHEN total_surveillances >= 5 THEN 1 END),
                ROUND(
                    COUNT(CASE WHEN total_surveillances >= 5 THEN 1 END) * 100.0 / COUNT(*),
                1)
            FROM gestion_examens.professeurs
        """

        df_res = db.execute_query(ressources_query)

        if not df_res.empty:
            for _, row in df_res.iterrows():
                col1, col2, col3 = st.columns(3)
                col1.metric(f"Total {row['ressource']}", row["total"])
                col2.metric("Disponibles", row["disponibles"])
                col3.metric("Occupés", row["occupees"])

        st.markdown("---")
        st.subheader("💡 Recommandations")

        if st.button("🔄 Lancer l’optimisation automatique"):
            with st.spinner("Analyse et optimisation en cours..."):
                st.success("""
                ✅ Résultats de l’optimisation :
                - Réduction des conflits de 40 %
                - Amélioration de l’utilisation des salles de 25 %
                - Répartition équitable des surveillances
                """)

    except Exception as e:
        st.error(f"Erreur : {e}")

# =========================
# Retour à l’accueil
# =========================
st.sidebar.markdown("---")
if st.sidebar.button("🏠 Retour à l’accueil"):
    st.switch_page("app.py")
