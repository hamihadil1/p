# 4_👨‍🎓_Etudiants.py - صفحة الطالب
import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import datetime, timedelta
from database import db

# إعداد الصفحة
st.set_page_config(
    page_title="Étudiant - Examens Universitaires",
    page_icon="👨‍🎓",
    layout="wide"
)

# ============================================
# STYLES CSS
# ============================================
st.markdown("""
<style>
    .student-header {
        font-size: 2.5rem;
        background: linear-gradient(90deg, #3B82F6, #8B5CF6);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-align: center;
        margin-bottom: 1rem;
    }
    .exam-card {
        background: white;
        padding: 1.5rem;
        border-radius: 12px;
        box-shadow: 0 6px 20px rgba(0,0,0,0.1);
        margin-bottom: 1.5rem;
        border-left: 6px solid #3B82F6;
        transition: transform 0.3s;
    }
    .exam-card:hover {
        transform: translateY(-5px);
    }
    .urgent-exam {
        border-left: 6px solid #EF4444;
        background: linear-gradient(135deg, #FEF2F2, #FFFFFF);
    }
    .today-exam {
        border-left: 6px solid #10B981;
        background: linear-gradient(135deg, #F0FDF4, #FFFFFF);
    }
    .info-card {
        background: linear-gradient(135deg, #E0F2FE, #F0F9FF);
        padding: 1.5rem;
        border-radius: 12px;
        border-left: 6px solid #0EA5E9;
    }
</style>
""", unsafe_allow_html=True)

# ============================================
# PAGE TITLE
# ============================================
st.markdown('<h1 class="student-header">👨‍🎓 Espace Étudiant</h1>', unsafe_allow_html=True)

# ============================================
# SIMULATION DE CONNEXION ÉTUDIANT
# ============================================
st.sidebar.header("👤 Connexion Étudiant")

# Liste des étudiants pour simulation
try:
    df_etudiants = db.execute_query("""
        SELECT id, matricule, nom, prenom, formation_id 
        FROM gestion_examens.etudiants 
        WHERE statut = 'actif'
        LIMIT 50
    """)
    
    if not df_etudiants.empty:
        etudiants_liste = [
            f"{row['matricule']} - {row['prenom']} {row['nom']}" 
            for _, row in df_etudiants.iterrows()
        ]
        etudiants_ids = [row['id'] for _, row in df_etudiants.iterrows()]
    else:
        etudiants_liste = ["ETU-2024-00001 - Mohamed Nom_1"]
        etudiants_ids = [1]
    
except:
    etudiants_liste = ["ETU-2024-00001 - Mohamed Nom_1"]
    etudiants_ids = [1]

# Sélection de l'étudiant (simulation)
selected_student = st.sidebar.selectbox(
    "Sélectionnez votre compte",
    options=etudiants_liste,
    index=0
)

# Récupérer l'ID de l'étudiant
student_idx = etudiants_liste.index(selected_student)
student_id = etudiants_ids[student_idx]

# ============================================
# ONGLETS PRINCIPAUX
# ============================================
tab1, tab2, tab3, tab4 = st.tabs([
    "📅 Mon Emploi du Temps", 
    "📚 Mes Notes", 
    "📝 Mes Examens", 
    "ℹ️ Mes Informations"
])

# ============================================
# TAB 1: EMPLOI DU TEMPS
# ============================================
with tab1:
    st.header("📅 Mon Emploi du Temps d'Examens")
    
    try:
        # Récupérer l'emploi du temps de l'étudiant
        df_emploi = db.execute_query("""
            SELECT 
                etudiant_nom,
                module_nom,
                formation_nom,
                departement_nom,
                professeur,
                salle,
                type_salle,
                date_examen,
                heure_examen,
                date_heure,
                duree_minutes
            FROM gestion_examens.vue_emploi_temps_etudiant 
            WHERE etudiant_id = %s
            ORDER BY date_heure
        """, (student_id,))
        
        if not df_emploi.empty:
            # Afficher le nom de l'étudiant
            student_name = df_emploi['etudiant_nom'].iloc[0]
            st.success(f"👋 Bienvenue, {student_name}")
            
            # Statistiques rapides
            col1, col2, col3 = st.columns(3)
            
            with col1:
                nb_examens = len(df_emploi)
                st.metric("📝 Nombre d'examens", nb_examens)
            
            with col2:
                # Prochain examen
                df_future = df_emploi[pd.to_datetime(df_emploi['date_heure']) > datetime.now()]
                if not df_future.empty:
                    prochain = df_future.iloc[0]
                    days_left = (pd.to_datetime(prochain['date_heure']) - datetime.now()).days
                    st.metric("⏳ Jours avant prochain", days_left)
                else:
                    st.metric("✅ Examens terminés", "0")
            
            with col3:
                # Examens aujourd'hui
                aujourdhui = datetime.now().strftime('%d/%m/%Y')
                exam_aujourdhui = df_emploi[df_emploi['date_examen'] == aujourdhui]
                st.metric("📅 Aujourd'hui", len(exam_aujourdhui))
            
            st.markdown("---")
            
            # Filtres
            col1, col2 = st.columns(2)
            
            with col1:
                # Filtre par date
                date_options = ["Toutes dates", "Aujourd'hui", "Cette semaine", "Ce mois"]
                selected_date = st.selectbox("Filtrer par période", date_options)
                
            with col2:
                # Filtre par module
                modules = ["Tous modules"] + df_emploi['module_nom'].unique().tolist()
                selected_module = st.selectbox("Filtrer par module", modules)
            
            # Appliquer les filtres
            filtered_df = df_emploi.copy()
            
            if selected_date == "Aujourd'hui":
                filtered_df = filtered_df[filtered_df['date_examen'] == aujourdhui]
            elif selected_date == "Cette semaine":
                # Logique pour cette semaine
                pass
            elif selected_date == "Ce mois":
                # Logique pour ce mois
                pass
            
            if selected_module != "Tous modules":
                filtered_df = filtered_df[filtered_df['module_nom'] == selected_module]
            
            # Afficher les examens
            if not filtered_df.empty:
                st.subheader(f"📋 {len(filtered_df)} examens trouvés")
                
                for idx, exam in filtered_df.iterrows():
                    # Déterminer le style de la carte
                    card_class = "exam-card"
                    if exam['date_examen'] == aujourdhui:
                        card_class = "today-exam"
                    
                    # Calculer les jours restants
                    exam_date = pd.to_datetime(exam['date_heure'])
                    days_left = (exam_date - datetime.now()).days
                    
                    # Afficher la carte d'examen
                    with st.container():
                        st.markdown(f"""
                        <div class="{card_class}">
                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <div>
                                    <h3 style="margin: 0; color: #1F2937;">{exam['module_nom']}</h3>
                                    <p style="margin: 0.5rem 0; color: #6B7280;">
                                        📚 {exam['formation_nom']} | 👨‍🏫 {exam['professeur']}
                                    </p>
                                </div>
                                <div style="text-align: right;">
                                    <h2 style="margin: 0; color: #3B82F6;">{exam['heure_examen']}</h2>
                                    <p style="margin: 0; color: #6B7280;">{exam['date_examen']}</p>
                                </div>
                            </div>
                            
                            <div style="margin-top: 1rem; display: flex; justify-content: space-between;">
                                <div>
                                    <span style="background: #E0F2FE; padding: 0.3rem 0.8rem; border-radius: 20px;">
                                        🏢 {exam['salle']} ({exam['type_salle']})
                                    </span>
                                    <span style="background: #F0F9FF; padding: 0.3rem 0.8rem; border-radius: 20px; margin-left: 0.5rem;">
                                        ⏱️ {exam['duree_minutes']} minutes
                                    </span>
                                </div>
                                
                                <div>
                                    <span style="background: {'#FEF2F2' if days_left <= 3 else '#F0FDF4'}; 
                                            padding: 0.3rem 0.8rem; border-radius: 20px; 
                                            color: {'#DC2626' if days_left <= 3 else '#059669'};">
                                        ⏳ {days_left} jours restants
                                    </span>
                                </div>
                            </div>
                        </div>
                        """, unsafe_allow_html=True)
                
                # Visualisation calendrier
                st.markdown("---")
                st.subheader("📊 Vue calendrier")
                
                # Préparer les données pour le calendrier
                df_calendar = filtered_df.copy()
                df_calendar['date'] = pd.to_datetime(df_calendar['date_heure'])
                df_calendar['count'] = 1
                
                # Graphique de densité
                fig = px.density_heatmap(
                    df_calendar,
                    x='date',
                    y='module_nom',
                    title='Répartition des examens dans le temps',
                    color_continuous_scale='Viridis',
                    labels={'date': 'Date', 'module_nom': 'Module'}
                )
                st.plotly_chart(fig, use_container_width=True)
                
            else:
                st.info("🎉 Aucun examen trouvé avec les filtres sélectionnés")
        
        else:
            st.info("📭 Aucun emploi du temps d'examens trouvé pour cet étudiant")
            st.markdown("""
            <div class="info-card">
                <h4 style="margin-top: 0;">ℹ️ Information</h4>
                <p>Votre emploi du temps d'examens n'est pas encore disponible.</p>
                <p>Veuillez contacter votre département pour plus d'informations.</p>
            </div>
            """, unsafe_allow_html=True)
    
    except Exception as e:
        st.error(f"Erreur lors du chargement de l'emploi du temps: {e}")

# ============================================
# TAB 2: NOTES
# ============================================
with tab2:
    st.header("📚 Mes Notes et Résultats")
    
    try:
        # Récupérer les notes de l'étudiant
        df_notes = db.execute_query("""
            SELECT 
                m.nom as module,
                m.code as code_module,
                m.credits,
                i.note,
                i.statut,
                TO_CHAR(i.updated_at, 'DD/MM/YYYY') as date_notation
            FROM gestion_examens.inscriptions i
            JOIN gestion_examens.modules m ON i.module_id = m.id
            WHERE i.etudiant_id = %s AND i.note IS NOT NULL
            ORDER BY i.updated_at DESC
        """, (student_id,))
        
        if not df_notes.empty:
            # Statistiques des notes
            col1, col2, col3 = st.columns(3)
            
            with col1:
                moyenne = df_notes['note'].mean()
                st.metric("📊 Moyenne générale", f"{moyenne:.2f}/20")
            
            with col2:
                credits_total = df_notes['credits'].sum()
                st.metric("🎯 Crédits acquis", credits_total)
            
            with col3:
                modules_valides = df_notes[df_notes['statut'] == 'valide'].shape[0]
                st.metric("✅ Modules validés", modules_valides)
            
            st.markdown("---")
            
            # Graphique des notes
            st.subheader("📈 Évolution des notes")
            
            col1, col2 = st.columns(2)
            
            with col1:
                # Histogramme des notes
                fig = px.histogram(
                    df_notes,
                    x='note',
                    nbins=20,
                    title='Distribution des notes',
                    color='statut',
                    color_discrete_map={
                        'valide': '#10B981',
                        'echec': '#EF4444',
                        'en_cours': '#3B82F6'
                    }
                )
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                # Graphique à barres par module
                df_sorted = df_notes.sort_values('note')
                fig = px.bar(
                    df_sorted,
                    x='module',
                    y='note',
                    title='Notes par module',
                    color='note',
                    color_continuous_scale='RdYlGn',
                    text='note'
                )
                fig.update_traces(texttemplate='%{text:.1f}', textposition='outside')
                st.plotly_chart(fig, use_container_width=True)
            
            # Tableau détaillé des notes
            st.subheader("📋 Détail des notes")
            
            # Formater le tableau
            def color_note(val):
                if val >= 16:
                    return 'background-color: #10B981; color: white;'
                elif val >= 12:
                    return 'background-color: #3B82F6; color: white;'
                elif val >= 10:
                    return 'background-color: #F59E0B; color: white;'
                else:
                    return 'background-color: #EF4444; color: white;'
            
            styled_df = df_notes.style.applymap(color_note, subset=['note'])
            st.dataframe(styled_df.format({'note': '{:.2f}'}))
            
            # Téléchargement des notes
            csv = df_notes.to_csv(index=False)
            st.download_button(
                "📥 Télécharger mes notes (CSV)",
                csv,
                file_name=f"notes_etudiant_{student_id}_{datetime.now().strftime('%Y%m%d')}.csv",
                mime="text/csv"
            )
        
        else:
            st.info("📭 Aucune note disponible pour le moment")
            st.markdown("""
            <div class="info-card">
                <h4 style="margin-top: 0;">ℹ️ Information</h4>
                <p>Vos notes ne sont pas encore disponibles.</p>
                <p>Les résultats seront publiés après correction des examens.</p>
            </div>
            """, unsafe_allow_html=True)
    
    except Exception as e:
        st.error(f"Erreur lors du chargement des notes: {e}")

# ============================================
# TAB 3: EXAMENS DÉTAILLÉS
# ============================================
with tab3:
    st.header("📝 Détails de mes Examens")
    
    try:
        # Informations détaillées sur chaque examen
        df_examens_detailed = db.execute_query("""
            SELECT 
                e.id,
                m.nom as module,
                m.code as code_module,
                f.nom as formation,
                p.prenom || ' ' || p.nom as professeur,
                p.email as email_professeur,
                s.nom as salle,
                s.type as type_salle,
                s.batiment,
                s.code as code_salle,
                TO_CHAR(ex.date_heure, 'DD/MM/YYYY') as date_examen,
                TO_CHAR(ex.date_heure, 'HH24:MI') as heure_examen,
                ex.duree_minutes,
                ex.type_examen,
                ex.statut
            FROM gestion_examens.examens ex
            JOIN gestion_examens.modules m ON ex.module_id = m.id
            JOIN gestion_examens.formations f ON ex.formation_id = f.id
            JOIN gestion_examens.professeurs p ON ex.professeur_responsable_id = p.id
            JOIN gestion_examens.salles_examen s ON ex.salle_id = s.id
            WHERE ex.module_id IN (
                SELECT module_id 
                FROM gestion_examens.inscriptions 
                WHERE etudiant_id = %s AND statut IN ('inscrit', 'en_cours')
            )
            AND ex.statut IN ('planifie', 'confirme')
            ORDER BY ex.date_heure
        """, (student_id,))
        
        if not df_examens_detailed.empty:
            # Afficher chaque examen avec détails
            for idx, exam in df_examens_detailed.iterrows():
                with st.expander(f"{exam['module']} - {exam['date_examen']} {exam['heure_examen']}", expanded=False):
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.markdown(f"""
                        **📚 Module:** {exam['module']} ({exam['code_module']})
                        
                        **🎓 Formation:** {exam['formation']}
                        
                        **👨‍🏫 Professeur:** {exam['professeur']}
                        
                        **📧 Email:** {exam['email_professeur']}
                        
                        **📝 Type d'examen:** {exam['type_examen']}
                        """)
                    
                    with col2:
                        st.markdown(f"""
                        **🏢 Salle:** {exam['salle']} ({exam['code_salle']})
                        
                        **🏛️ Bâtiment:** {exam['batiment']}
                        
                        **⏱️ Durée:** {exam['duree_minutes']} minutes
                        
                        **📅 Date:** {exam['date_examen']}
                        
                        **🕐 Heure:** {exam['heure_examen']}
                        
                        **📊 Statut:** {exam['statut']}
                        """)
                    
                    # Ajouter une carte Google Maps simulée (pour l'adresse)
                    st.markdown("### 🗺️ Localisation de la salle")
                    st.info(f"📍 {exam['batiment']} - Salle {exam['salle']}")
                    
                    # Instructions pour l'examen
                    st.markdown("### 📋 Instructions importantes")
                    st.markdown("""
                    1. Présentez-vous 30 minutes avant le début de l'examen
                    2. Ayez votre carte d'étudiant et votre pièce d'identité
                    3. Les calculatrices sont autorisées sauf indication contraire
                    4. Les téléphones portables doivent être éteints et rangés
                    5. Aucun document n'est autorisé sauf mention explicite
                    """)
            
            # Section pour ajouter des rappels
            st.markdown("---")
            st.subheader("🔔 Rappels personnels")
            
            col1, col2 = st.columns([3, 1])
            
            with col1:
                rappel_text = st.text_input("Ajouter un rappel pour mes examens")
            
            with col2:
                if st.button("➕ Ajouter", use_container_width=True):
                    if rappel_text:
                        st.success("Rappel ajouté!")
                        # Ici, normalement, on sauvegarderait en base de données
        
        else:
            st.info("📭 Aucun examen détaillé disponible")
    
    except Exception as e:
        st.error(f"Erreur: {e}")

# ============================================
# TAB 4: INFORMATIONS PERSONNELLES
# ============================================
with tab4:
    st.header("ℹ️ Mes Informations Personnelles")
    
    try:
        # Récupérer les informations de l'étudiant
        df_info = db.execute_query("""
            SELECT 
                e.matricule,
                e.nom,
                e.prenom,
                e.email,
                e.promo,
                e.annee_inscription,
                e.statut,
                f.nom as formation,
                d.nom as departement,
                g.nom as groupe
            FROM gestion_examens.etudiants e
            JOIN gestion_examens.formations f ON e.formation_id = f.id
            JOIN gestion_examens.departements d ON f.dept_id = d.id
            LEFT JOIN gestion_examens.groupes g ON e.groupe_id = g.id
            WHERE e.id = %s
        """, (student_id,))
        
        if not df_info.empty:
            info = df_info.iloc[0]
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("### 👤 Identité")
                st.markdown(f"""
                **Matricule:** {info['matricule']}
                
                **Nom:** {info['nom']}
                
                **Prénom:** {info['prenom']}
                
                **Email:** {info['email']}
                
                **Statut:** {info['statut']}
                """)
            
            with col2:
                st.markdown("### 🎓 Scolarité")
                st.markdown(f"""
                **Formation:** {info['formation']}
                
                **Département:** {info['departement']}
                
                **Groupe:** {info['groupe'] if info['groupe'] else 'Non assigné'}
                
                **Promotion:** {info['promo']}
                
                **Année d'inscription:** {info['annee_inscription']}
                """)
            
            # Informations académiques supplémentaires
            st.markdown("---")
            st.subheader("📊 Situation académique")
            
            try:
                df_situation = db.execute_query("""
                    SELECT 
                        COUNT(*) as total_modules,
                        SUM(CASE WHEN i.statut = 'valide' THEN 1 ELSE 0 END) as modules_valides,
                        SUM(CASE WHEN i.statut = 'echec' THEN 1 ELSE 0 END) as modules_echec,
                        SUM(CASE WHEN i.statut = 'en_cours' THEN 1 ELSE 0 END) as modules_en_cours,
                        SUM(m.credits) as credits_total,
                        SUM(CASE WHEN i.statut = 'valide' THEN m.credits ELSE 0 END) as credits_acquits
                    FROM gestion_examens.inscriptions i
                    JOIN gestion_examens.modules m ON i.module_id = m.id
                    WHERE i.etudiant_id = %s
                """, (student_id,))
                
                if not df_situation.empty:
                    sit = df_situation.iloc[0]
                    
                    col1, col2, col3, col4 = st.columns(4)
                    
                    with col1:
                        st.metric("📚 Modules total", sit['total_modules'])
                    
                    with col2:
                        st.metric("✅ Modules validés", sit['modules_valides'])
                    
                    with col3:
                        st.metric("🎯 Crédits total", sit['credits_total'])
                    
                    with col4:
                        taux_credits = (sit['credits_acquits'] / sit['credits_total'] * 100) if sit['credits_total'] > 0 else 0
                        st.metric("📈 Crédits acquis", f"{taux_credits:.1f}%")
            
            except:
                st.info("Informations académiques non disponibles")
        
        else:
            st.error("Informations non disponibles")
    
    except Exception as e:
        st.error(f"Erreur: {e}")
    
    # Section de contact
    st.markdown("---")
    st.subheader("📞 Contact et support")
    
    st.markdown("""
    <div class="info-card">
        <h4 style="margin-top: 0;">💼 Secrétariat pédagogique</h4>
        <p><strong>📧 Email:</strong> secretariat@univ.fr</p>
        <p><strong>📞 Téléphone:</strong> +212 5 XX XX XX XX</p>
        <p><strong>🕐 Horaires:</strong> Lundi - Vendredi, 8h30 - 16h30</p>
        
        <h4 style="margin-top: 1.5rem;">🆘 Urgences examens</h4>
        <p>Pour toute urgence concernant un examen (empêchement, problème technique, etc.)</p>
        <p><strong>📧 Email:</strong> urgences-examens@univ.fr</p>
        <p><strong>📞 Téléphone:</strong> +212 5 XX XX XX XX</p>
    </div>
    """, unsafe_allow_html=True)

# ============================================
# PIED DE PAGE
# ============================================
st.markdown("---")
st.markdown("""
<div style="text-align: center; color: #6B7280; padding: 1rem;">
    👨‍🎓 <strong>Espace Étudiant</strong> | 
    Plateforme d'Optimisation des Examens Universitaires | 
    © 2025
</div>
""", unsafe_allow_html=True)

# Bouton de retour
if st.sidebar.button("🏠 Retour à l'accueil"):
    st.switch_page("app.py")