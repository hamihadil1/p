﻿# app.py
# Application principale Streamlit pour la plateforme des examens universitaires

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
from database import db


# =========================
# Configuration de la page
# =========================
st.set_page_config(
    page_title="Plateforme Examens Universitaires",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)


# =========================
# Styles CSS personnalisés
# =========================
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #1E3A8A;
        text-align: center;
        padding: 1rem;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 2rem;
    }
    .kpi-card {
        background: white;
        padding: 1.5rem;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        text-align: center;
        border-left: 5px solid #3B82F6;
    }
</style>
""", unsafe_allow_html=True)


# =========================
# Fonction principale
# =========================
def main():
    """
    Page d'accueil principale de la plateforme
    """

    # Titre principal
    st.markdown(
        '<h1 class="main-header">🎓 Plateforme d’Optimisation des Emplois du Temps d’Examens</h1>',
        unsafe_allow_html=True
    )

    # =========================
    # Test de connexion BD
    # =========================
    with st.spinner("🔗 Vérification de la connexion à la base de données..."):
        if db.connect():
            st.success("✅ Connexion à la base de données réussie")
        else:
            st.error("❌ Échec de la connexion à la base de données")
            st.info("""
            **Veuillez vérifier :**
            - PostgreSQL est démarré
            - La base de données `unuversity` existe
            - Utilisateur : postgres
            - Mot de passe : 0000
            - Port : 5433
            """)
            return

    st.markdown("---")

    # =========================
    # Choix du rôle utilisateur
    # =========================
    st.subheader("👥 Choisissez votre rôle")

    col1, col2, col3, col4, col5 = st.columns(5)

    with col1:
        if st.button("👑 Vice Doyen", use_container_width=True):
            st.switch_page("pages/Vice_Doyen.py")

    with col2:
        if st.button("⚙️ Administrateur", use_container_width=True):
            st.switch_page("pages/Administrateur.py")

    with col3:
        if st.button("📊 Chef de Département", use_container_width=True):
            st.switch_page("pages/Chef_Departement.py")

    with col4:
        if st.button("👨‍🎓 Étudiant", use_container_width=True):
            st.switch_page("pages/Etudiants.py")

    with col5:
        if st.button("👨‍🏫 Professeur", use_container_width=True):
            st.switch_page("pages/Professeurs.py")

    st.markdown("---")

    # =========================
    # Statistiques globales
    # =========================
    st.subheader("📈 Aperçu global du système")

    try:
        # Nombre d'étudiants actifs
        df_etudiants = db.execute_query("""
            SELECT COUNT(*) AS nb
            FROM gestion_examens.etudiants
            WHERE statut = 'actif'
        """)
        nb_etudiants = df_etudiants["nb"].iloc[0] if not df_etudiants.empty else 0

        # Nombre d'examens planifiés
        df_examens = db.execute_query("""
            SELECT COUNT(*) AS nb
            FROM gestion_examens.examens
            WHERE statut = 'planifie'
        """)
        nb_examens = df_examens["nb"].iloc[0] if not df_examens.empty else 0

        # Nombre de professeurs actifs
        df_profs = db.execute_query("""
            SELECT COUNT(*) AS nb
            FROM gestion_examens.professeurs
            WHERE statut = 'actif'
        """)
        nb_profs = df_profs["nb"].iloc[0] if not df_profs.empty else 0

        # Nombre de conflits détectés
        df_conflits = db.execute_query("""
            SELECT COUNT(*) AS nb
            FROM gestion_examens.vue_conflits
        """)
        nb_conflits = df_conflits["nb"].iloc[0] if not df_conflits.empty else 0

        col1, col2, col3, col4 = st.columns(4)

        col1.metric("👨‍🎓 Étudiants actifs", nb_etudiants)
        col2.metric("📝 Examens planifiés", nb_examens)
        col3.metric("👨‍🏫 Professeurs actifs", nb_profs)
        col4.metric("⚠️ Conflits", nb_conflits)

    except Exception as e:
        st.warning(f"⚠️ Impossible de charger les statistiques : {e}")

    # =========================
    # Zone de test SQL
    # =========================
    st.markdown("---")
    st.subheader("🧪 Tests de requêtes")

    if st.button("🔍 Tester la table Étudiants"):
        df = db.execute_query("""
            SELECT matricule, nom, prenom, formation_id
            FROM gestion_examens.etudiants
            LIMIT 5
        """)
        st.dataframe(df)

    if st.button("📊 Tester la vue Emploi du Temps"):
        df = db.execute_query("""
            SELECT *
            FROM gestion_examens.vue_emploi_temps_etudiant
            LIMIT 5
        """)
        st.dataframe(df)


# =========================
# Lancement de l'application
# =========================
if __name__ == "__main__":
    main()
