﻿-- ================================================
-- CORRECTIONS FINALES POUR LA DÉMONSTRATION
-- ================================================

SET search_path TO gestion_examens;
SET client_encoding = ''UTF8'';

-- 1. Ajouter des surveillants manuellement (car le trigger ne fonctionne pas)
SELECT ''=== AJOUT DE SURVEILLANTS ==='' as etape;

DO $$
DECLARE
    exam_rec RECORD;
    prof_rec RECORD;
    total_added INTEGER := 0;
    i INTEGER;
BEGIN
    -- Pour chaque examen sans surveillants
    FOR exam_rec IN 
        SELECT e.*, f.dept_id 
        FROM examens e
        JOIN modules m ON e.module_id = m.id
        JOIN formations f ON m.formation_id = f.id
        WHERE e.statut = ''planifie''
        AND NOT EXISTS (SELECT 1 FROM surveillances s WHERE s.examen_id = e.id)
    LOOP
        -- Reset counter pour cet examen
        i := 0;
        
        -- Chercher 2 surveillants du même département
        FOR prof_rec IN (
            SELECT p.id 
            FROM professeurs p
            WHERE p.dept_id = exam_rec.dept_id
            AND p.id != exam_rec.professeur_responsable_id
            AND p.statut = ''actif''
            ORDER BY p.total_surveillances ASC
            LIMIT 2
        ) LOOP
            INSERT INTO surveillances (examen_id, professeur_id, priorite, role, heures_creditees)
            VALUES (exam_rec.id, prof_rec.id, 1, ''surveillant'', 1.5);
            
            UPDATE professeurs 
            SET total_surveillances = total_surveillances + 1
            WHERE id = prof_rec.id;
            
            i := i + 1;
            total_added := total_added + 1;
        END LOOP;
        
        -- Si pas assez, chercher dans d''autres départements
        IF i < 2 THEN
            FOR j IN 1..(2 - i) LOOP
                SELECT p.id INTO prof_rec
                FROM professeurs p
                WHERE p.dept_id != exam_rec.dept_id
                AND p.statut = ''actif''
                AND p.id != exam_rec.professeur_responsable_id
                AND NOT EXISTS (
                    SELECT 1 FROM surveillances s 
                    WHERE s.examen_id = exam_rec.id AND s.professeur_id = p.id
                )
                ORDER BY p.total_surveillances ASC
                LIMIT 1;
                
                IF prof_rec.id IS NOT NULL THEN
                    INSERT INTO surveillances (examen_id, professeur_id, priorite, role, heures_creditees)
                    VALUES (exam_rec.id, prof_rec.id, 2, ''surveillant'', 1.5);
                    
                    UPDATE professeurs 
                    SET total_surveillances = total_surveillances + 1
                    WHERE id = prof_rec.id;
                    
                    total_added := total_added + 1;
                END IF;
            END LOOP;
        END IF;
    END LOOP;
    
    RAISE NOTICE ''✅ % surveillants ajoutés manuellement'', total_added;
END $$;

-- 2. Mettre à jour la vue des surveillances
SELECT ''=== MISE À JOUR DES VUES ==='' as etape;
REFRESH MATERIALIZED VIEW vue_surveillances_professeur;

-- 3. Statistiques finales
SELECT ''=== STATISTIQUES FINALES ==='' as etape;

SELECT 
    ''Étudiants actifs'' as categorie,
    COUNT(*)::TEXT as valeur
FROM etudiants 
WHERE statut = ''actif''
UNION ALL
SELECT 
    ''Examens planifiés'',
    COUNT(*)::TEXT
FROM examens 
WHERE statut = ''planifie''
UNION ALL
SELECT 
    ''Surveillances attribuées'',
    COUNT(*)::TEXT
FROM surveillances
UNION ALL
SELECT 
    ''Conflits détectés'',
    COUNT(*)::TEXT
FROM vue_conflits
UNION ALL
SELECT 
    ''Salles utilisées'',
    COUNT(DISTINCT salle_id)::TEXT || '' / '' || (SELECT COUNT(*) FROM salles_examen)::TEXT
FROM examens 
WHERE statut = ''planifie''
ORDER BY categorie;

-- 4. Exemple de données pour la démo
SELECT ''=== EXEMPLE POUR DÉMO ==='' as etape;

SELECT ''Emploi du temps étudiant:'' as exemple;
SELECT etudiant_nom, module_nom, date_examen, heure_examen, salle, professeur
FROM vue_emploi_temps_etudiant 
WHERE etudiant_nom LIKE ''%Nom_1%''
ORDER BY date_heure
LIMIT 3;

SELECT ''Surveillances par professeur:'' as exemple;
SELECT p.prenom || '' '' || p.nom as professeur, COUNT(s.id) as nb_surveillances
FROM professeurs p
LEFT JOIN surveillances s ON p.id = s.professeur_id
GROUP BY p.id, p.prenom, p.nom
ORDER BY nb_surveillances DESC
LIMIT 5;

-- 5. Message de succès
DO $$
BEGIN
    RAISE NOTICE ''========================================'';
    RAISE NOTICE ''SYSTÈME COMPLETEMENT CONFIGURÉ ! 🎉'';
    RAISE NOTICE ''========================================'';
    RAISE NOTICE ''Toutes les corrections ont été appliquées.'';
    RAISE NOTICE ''Le système est prêt pour la démonstration.'';
    RAISE NOTICE ''========================================'';
END $$;
